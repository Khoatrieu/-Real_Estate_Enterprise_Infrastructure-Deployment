# TESTING

## Backend

```bash
cd backend
npm install
cp .env.example .env
npm run dev
curl http://localhost:5000/api/health
```

Đăng nhập:

```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"123456"}'
```

Kiểm tra route có JWT:

```bash
curl http://localhost:5000/api/dashboard/summary \
  -H "Authorization: Bearer <token>"
```

## Frontend

```bash
cd frontend
npm install
npm run dev
```

Mở `http://localhost:5173`, đăng nhập `admin / 123456`, kiểm tra:

- Dashboard có card thống kê và chart.
- Các trang có bảng, tìm kiếm, lọc trạng thái, thêm/sửa/xóa.
- Modal lưu dữ liệu hiển thị thông báo thành công/thất bại.
- Xóa có hộp xác nhận.
- Đăng xuất quay về trang login.

## Database

Trong SQL Server Management Studio:

```sql
SELECT COUNT(*) AS EmployeeCount FROM Employees;
SELECT COUNT(*) AS CustomerCount FROM Customers;
SELECT COUNT(*) AS ProjectCount FROM Projects;
SELECT COUNT(*) AS PropertyCount FROM Properties;
SELECT COUNT(*) AS VlanCount FROM VLANs;
```

Kết quả kỳ vọng: `120`, `850`, `12`, `320`, `16`.
