module.exports = {
  apps: [
    {
      name: "real-estate-backend",
      script: "server.js",
      cwd: "/var/www/real-estate-it-system/backend",
      env: {
        PORT: 5000,
        NODE_ENV: "production"
      }
    }
  ]
};
