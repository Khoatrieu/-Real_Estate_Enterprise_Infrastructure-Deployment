# DEPLOYMENT

Triển khai trên Ubuntu App Server `192.168.1.151`.

## 1. Chuẩn bị server

```bash
sudo apt update
sudo apt install -y git curl nginx
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm install -g pm2
```

## 2. Copy source code

```bash
sudo mkdir -p /var/www/real-estate-it-system
sudo chown -R $USER:$USER /var/www/real-estate-it-system
git clone <repo-url> /var/www/real-estate-it-system
cd /var/www/real-estate-it-system
```

## 3. Cấu hình backend

```bash
cd backend
cp .env.example .env
nano .env
npm install
npm run health
```

Nội dung `.env` production:

```env
PORT=5000
NODE_ENV=production
JWT_SECRET=real_estate_secret_key_change_me
JWT_EXPIRES_IN=1d
DB_HOST=192.168.1.101
DB_PORT=1433
DB_NAME=RealEstateITSystem
DB_USER=realestate_app
DB_PASSWORD=RealEstate@123456
DB_ENCRYPT=false
DB_TRUST_SERVER_CERTIFICATE=true
USE_SQL_SERVER=false
```

Đặt `USE_SQL_SERVER=true` khi muốn API health kiểm tra kết nối SQL Server.

## 4. Chạy backend bằng PM2

```bash
cd /var/www/real-estate-it-system
pm2 start deployment/ecosystem.config.js
pm2 save
pm2 startup
```

Kiểm tra:

```bash
curl http://127.0.0.1:5000/api/health
```

## 5. Build frontend

```bash
cd /var/www/real-estate-it-system/frontend
cp .env.example .env
nano .env
npm install
npm run build
```

File `.env` frontend:

```env
VITE_API_URL=http://192.168.1.151/api
```

## 6. Cấu hình Nginx

```bash
sudo cp /var/www/real-estate-it-system/deployment/nginx-real-estate.conf /etc/nginx/sites-available/real-estate-it-system
sudo ln -s /etc/nginx/sites-available/real-estate-it-system /etc/nginx/sites-enabled/real-estate-it-system
sudo nginx -t
sudo systemctl reload nginx
```

Mở firewall Ubuntu:

```bash
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw reload
```

## 7. Kiểm tra từ Windows Client

1. Mở `http://192.168.1.151`.
2. Kiểm tra `http://192.168.1.151/api/health`.
3. Đăng nhập `admin / 123456`.
4. Kiểm tra dashboard, VLAN, server, bảo mật, backup và các module nghiệp vụ.
