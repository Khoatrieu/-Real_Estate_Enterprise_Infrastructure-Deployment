# REPORT_NOTES

## Tổng quan hệ thống

Hệ thống CNTT cho công ty bất động sản mô phỏng doanh nghiệp có tối thiểu 120 nhân viên, gồm website public, CRM/App Server, Database Server, VLAN theo phòng ban, firewall pfSense, VPN, IDS/IPS và backup định kỳ.

## Website trong DMZ

Website giới thiệu dự án đặt tại Web Server DMZ `192.168.20.10`, phục vụ HTTP/HTTPS port `80/443`. Khách hàng Internet chỉ truy cập được Web Server trong DMZ, không truy cập LAN hoặc Database Server.

## CRM/App Server

App Server `192.168.1.151` chạy backend Node.js Express và phục vụ frontend React thông qua Nginx. Nhân viên nội bộ truy cập qua LAN, nhân viên từ xa truy cập qua VPN.

## Database Server

Database Server dùng Microsoft SQL Server, database `RealEstateITSystem`, IP `192.168.1.101`, port `1433`. Database lưu người dùng, nhân viên, khách hàng, dự án, sản phẩm, hợp đồng, kế toán, pháp lý, VLAN, server, thiết bị mạng, backup và cảnh báo.

## Windows Server 2025

Windows Server 2025 đảm nhiệm AD, DNS, DHCP và Database Server. DNS nội bộ dùng domain `realestate.local`; DHCP cấp phát scope theo từng VLAN.

## VLAN và phân tách mạng

Hệ thống có các VLAN Management, DMZ, Ban giám đốc, Hành chính, Môi giới, Marketing, Kế toán, Pháp lý, Chăm sóc khách hàng, IT, Meeting Room, WiFi nội bộ, WiFi khách, Server Farm, Camera/IoT và Backup. Mỗi VLAN có dải IP riêng, gateway riêng và chính sách ACL riêng.

## pfSense Firewall, DMZ và VPN

pfSense là gateway chính, firewall, IDS/IPS và VPN gateway. DMZ cô lập Web Server public khỏi LAN. VPN Site-to-Site kết nối trụ sở với chi nhánh; VPN Remote Access phục vụ nhân viên làm việc từ xa.

## ACL và Firewall Rule

Chính sách mẫu gồm Allow Internet to DMZ Web Server port `80/443`, Deny Internet to LAN, Allow LAN to App Server, Allow App Server to Database Server port `1433`, Deny Guest WiFi to LAN, Allow Guest WiFi to Internet only, Allow IT VLAN to manage servers and network devices, Deny direct SQL access from user VLANs, log all blocked traffic.

## IDS/IPS và Backup

IDS/IPS bật trên pfSense WAN để phát hiện truy cập bất thường. Backup Server được phép truy cập Database Server để sao lưu, thực hiện các job daily/weekly cho database, CRM, web, hợp đồng và tài liệu pháp lý.

## Luồng truy cập

Khách hàng Internet truy cập Web Server trong DMZ. Nhân viên nội bộ truy cập CRM qua LAN. Nhân viên từ xa truy cập qua VPN. App Server truy cập Database Server qua port `1433`. Database Server không public ra Internet.

## Lý do chọn SQL Server

SQL Server phù hợp với môi trường Windows Server 2025, tích hợp tốt với AD, có công cụ quản trị SSMS, hỗ trợ backup/restore mạnh, phân quyền rõ ràng và đáp ứng dữ liệu nghiệp vụ có quan hệ như khách hàng, dự án, hợp đồng, kế toán và pháp lý.
