# SQL_SETUP

## 1. Bật TCP/IP cho SQL Server

1. Mở SQL Server Configuration Manager trên Windows Server 2025.
2. Vào SQL Server Network Configuration.
3. Bật TCP/IP cho instance SQL Server.
4. Đặt TCP Port là `1433`.
5. Restart dịch vụ SQL Server.

## 2. Mở Windows Firewall

Tạo inbound rule cho TCP `1433` từ App Server `192.168.1.151`.

## 3. Tạo database và user

```sql
CREATE DATABASE RealEstateITSystem;
GO
USE RealEstateITSystem;
GO
CREATE LOGIN realestate_app WITH PASSWORD = 'RealEstate@123456';
CREATE USER realestate_app FOR LOGIN realestate_app;
EXEC sp_addrolemember 'db_datareader', 'realestate_app';
EXEC sp_addrolemember 'db_datawriter', 'realestate_app';
GO
```

## 4. Import schema và seed

Chạy theo thứ tự:

```sql
:r backend/database/schema.sql
:r backend/database/seed.sql
```

Hoặc mở từng file trong SQL Server Management Studio và Execute.

## 5. Test kết nối từ Ubuntu App Server

```bash
nc -vz 192.168.1.101 1433
curl http://127.0.0.1:5000/api/health
```

Database Server dùng IP `192.168.1.101`, database `RealEstateITSystem`, port `1433`.
